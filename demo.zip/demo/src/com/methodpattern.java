package com;

public class methodpattern {
	public static void pattern() {
		int i;
		int j;
		char a='A';
		for (i=0;i<=7;i++) {
			for (j=1;j<=i;j++) {
				System.out.print(a+"  ");
				a+=1;
			}
			System.out.println(a+" ");
		}
	}
		public static void main(String[] args) {
			pattern();
		}
	}