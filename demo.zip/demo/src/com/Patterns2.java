package com;

public class Patterns2 {
	public static void main(String[] args) {
		int i;
		int j;
		char a='A';
		for (i=1;i<=6;i++) {
			for (j=1;j<=i;j++) {
				System.out.print(a+" ");
				a+=1;
			}
			System.out.println( );
		}
	}

}
