package com;
import java.util.Scanner;
public class Methods {
	public static void user() {
		try (Scanner sc = new Scanner(System.in)) {
			System.out.println("Enter a Password:");
			String pass=sc.next();
			System.out.println("Enter 2nd Password:");
			String pass1=sc.next();
			System.out.println(pass.equals( pass1));
		}	
	}
	public static void main(String[] args) {
		user();
	}
}
