package com;

public class Patterns {
	public static void main(String[]arg) {
		int i;
		int j;
		for (i=1;i<=6;i++) {
			for (j=1;j<=i;j++) {
				System.out.print(i);
			}
			System.out.println(  );
		}
	}
	

}
